package pageClasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utils.Waits;

public class TnL_Enrollment extends Waits {

	WebDriver driver;
	
	public TnL_Enrollment(WebDriver driver) {
		this.driver = driver;
	}
	
	//PageObjects
	By NavBar = By.id("PT_NAVBAR$IMG");
	By menu = By.xpath("//*[@id=\"grouplet_PTNB$PTNUI_NB_MENU\"]");
	By Time_n_Labor = By.linkText("Time and Labor");
	By Enroll_Time_Reporters = By.linkText("Enroll Time Reporters");
	By Manage = By.linkText("Manage Time Reporter Data");
	By EmpId_textbox = By.xpath("//*[@id=\"EOSF_ADVSRC_DVW_EOSF_VALUE$0\"]");
	By search = By.linkText("Search");
	By taskGroup_search = By.xpath("//*[@id='TL_EMPL_DATA_TASKGROUP$prompt$0']");
	By work = By.id("TL_EMPL_DATA_WORKGROUP$prompt$0");
	By save = By.linkText("Save");
	
	
	
	//Methods
	public void navigateToManageTimeReporterData() {
		driver.findElement(NavBar).click();
		sleep();
		driver.switchTo().frame("psNavBarIFrame");
		driver.findElement(menu).click();
		sleep();
		driver.findElement(Time_n_Labor).click();
		sleep();
	    driver.findElement(Enroll_Time_Reporters).click();
	    sleep();
		driver.findElement(Manage).click();
		sleep();
	}
	public void EnrollTimeReporter(String EmpId) {
		driver.findElement(EmpId_textbox).sendKeys(EmpId);
		driver.findElement(search).click();
		sleep();
	
		//click on magnifier
		driver.findElement(taskGroup_search).click();
		sleep();
		driver.switchTo().frame(driver.findElement(By.xpath("//*[@id=\"ptModFrame_0\"]")));
		
		//select taskgroup
		sleep();
		driver.findElement(By.xpath("//*[@id=\"DERIVEDNUI_SRCH$0_row_0\"]")).click();
		driver.switchTo().parentFrame();
		sleep();
		
		//select work
		driver.findElement(work).click();
		sleep();
		driver.switchTo().frame(driver.findElement(By.xpath("//*[@id=\"ptModFrame_1\"]")));
		driver.findElement(By.xpath("//*[@id='NUI_SRCH0$0']")).click();
		driver.switchTo().parentFrame();
		sleep();
		driver.findElement(save).click();
	}
}
