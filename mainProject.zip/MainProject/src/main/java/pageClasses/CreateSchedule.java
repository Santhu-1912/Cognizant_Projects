package pageClasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import utils.Waits;

import java.awt.*;
import java.awt.event.KeyEvent;

public class CreateSchedule extends Waits {

		WebDriver driver;
		Actions action;
		
		public CreateSchedule(WebDriver driver){
			this.driver = driver;
			action=new Actions(driver);
		}
		
		//PageObjects
		By NavBar = By.id("PT_NAVBAR$IMG");
		By menu = By.xpath("//*[@id=\"grouplet_PTNB$PTNUI_NB_MENU\"]");
		By Set_Up_HCM = By.linkText("Set Up HCM");
		By Product_Related = By.linkText("Product Related");
		By Time_and_Labor = By.linkText("Time and Labor");
		By Schedule_Configurations = By.linkText("Schedule Configurations");
		By Set_up_schedules = By.linkText("Setup Schedules");
		By add_value = By.xpath("//*[@id='ICTAB_1']/span");
		By Set_Id_textBox = By.xpath("//*[@id=\"SCH_DEFN_TBL_SETID\"]");
		By Sch_Id_textBox = By.xpath(" //*[@id=\"SCH_DEFN_TBL_SCHEDULE_ID\"]");
		By description = By.xpath("//*[@id=\"SCH_DEFN_TBL_DESCR$0\"]");
		By schedule_shifts = By.xpath("//*[@id=\"ICTAB_1\"]");
		By shift_id_textBox = By.xpath("//*[@id=\"SCH_DEFN_DTL_SHIFT_ID$0\"]");
		By save = By.xpath("//*[@id=\"#ICSave\"]");
		
		//Methods
		public void navigateToCreateWorkSchedule() {
	        driver.findElement(NavBar).click();
	        sleep();
	        driver.switchTo().frame("psNavBarIFrame");
	        action.click(driver.findElement(menu)).build().perform();
	        sleep();
	        driver.findElement(Set_Up_HCM).click();
	        sleep();
	        driver.findElement(Product_Related).click();
	        sleep();
	        driver.findElement(Time_and_Labor).click();
	        sleep();
	        driver.findElement(Schedule_Configurations).click();
	        sleep();
	        driver.findElement(Set_up_schedules).click();
		}

		public void define_Schedule(String Schedule_id) {
	        driver.switchTo().frame("ptifrmtgtframe");
	
	        sleep();
	        //add new value
	        driver.findElement(add_value).click();
	        // create a Robot object to control the keyboard
	
	        sleep();
	         //set id
	       driver.findElement(Set_Id_textBox).sendKeys("IND");
	
	        sleep();
	        //schedule id
	        driver.findElement(Sch_Id_textBox).sendKeys(Schedule_id);
	        try{
	            Robot robot = new Robot();
	
	            // simulate pressing the "Enter" key
	            robot.keyPress(KeyEvent.VK_ENTER);
	
	            // simulate releasing the "Enter" key
	            robot.keyRelease(KeyEvent.VK_ENTER);
	        } catch (AWTException e) {
	            e.printStackTrace();
	        }
		}
		public void set_Up_Schedules() {
	        sleep();
	        driver.findElement(description).sendKeys("Morning Shift");
	        driver.findElement(schedule_shifts).click();
	        sleep();
	        driver.findElement(shift_id_textBox).sendKeys("10AM-10PM");
	        sleep();
	        driver.findElement(save).click();
	        sleep();
		}
}
