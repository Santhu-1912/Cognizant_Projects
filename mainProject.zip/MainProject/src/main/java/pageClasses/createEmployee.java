package pageClasses;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import utils.Waits;

public class createEmployee extends Waits{
		
		WebDriver driver;
	
		public createEmployee(WebDriver driver) {
			this.driver = driver;
			PageFactory.initElements(driver, this);
		}
	//create WebElements
		@FindBy(xpath ="//*[@id=\"PT_NAVBAR$IMG\"]")
		WebElement navBar;
		@FindBy(xpath = "//*[@id=\"grouplet_PTNB$PTNUI_NB_MENU\"]")
		WebElement menu;
		@FindBy(xpath ="//*[@id=\"PTMENUITEM$3\"]")
		WebElement workAdmin;
		@FindBy(xpath ="//*[@id=\"PTMENUITEM$0\"]")
		WebElement personalInfo;
		@FindBy(xpath ="//*[@id=\"PTMENUITEM$0\"]")
		WebElement biographical;
		@FindBy(xpath ="//*[@id=\"PTMENUITEM$0\"]")
		WebElement addNewPerson;
		@FindBy(xpath ="//*[@id=\"DERIVED_HR_EMPLID\"]")
		WebElement personId;
		@FindBy(xpath ="//*[@id=\"win0divDERIVED_HCR_PER_ADD_PERSON_LINK\"]/a")
		WebElement clickOnAdd;
		@FindBy(xpath ="//*[@id=\"NAMES_EFFDT$0\"]")
		
		
		WebElement effecDate;
		@FindBy(xpath ="//*[@id=\"DERIVED_NM_LVL2_UPDATE_NAME_BTN$0\"]")
		WebElement addNameBtn;
		@FindBy(xpath ="//*[@id=\"HCR_UPDNAME_DVW_FIRST_NAME$1\"]")
		WebElement firstName;
		@FindBy(xpath="//*[@id=\"HCR_UPDNAME_DVW_LAST_NAME$3\"]")
		WebElement lastName;
		@FindBy(xpath="//*[@id=\"win0divDERIVED_NM_LVL2_OK_PB\"]/a")
		WebElement okBtn;
		@FindBy(id ="PERSON_BIRTHDATE")
		WebElement dob;
		@FindBy(id ="PERSON_BIRTHCOUNTRY")
		WebElement birth_country;
		@FindBy(id ="PERSON_BIRTHSTATE")
		WebElement birth_state;
		@FindBy(id ="PERSON_BIRTHPLACE")
		WebElement birth_location;
		@FindBy(xpath ="//*[@id=\"PERS_NID_COUNTRY$prompt$0\"]")
		WebElement country;
		@FindBy(xpath = "//*[@id=\"RESULT1$12\"]")
		WebElement lookUpCntry;
		@FindBy(id ="DERIVED_HR_NID_SPECIAL_CHAR$0")
		WebElement national_ID;
		
		@FindBy(xpath ="//*[@id=\"#ICPanel1\"]")
		WebElement contact_Info;
		@FindBy(xpath ="//*[@id=\"ADDR_HISTORY_BTN$0\"]")
		WebElement addr_Details;
		@FindBy(xpath ="//*[@id=\"ADDRESSES_COUNTRY$0\"]")
		WebElement addr_country;
		@FindBy(xpath ="//*[@id=\"DERIVED_ADDR_UPDATE_ADDRESS$0\"]")
		WebElement add_Addr;
		@FindBy(xpath ="//*[@id=\"DERIVED_ADDRESS_ADDRESS1\"]")
		WebElement address;
		@FindBy(id ="DERIVED_ADDRESS_CITY")
		WebElement city;
		@FindBy(id ="DERIVED_ADDRESS_POSTAL")
		WebElement pincode;
		@FindBy(id ="DERIVED_ADDRESS_STATE")
		WebElement state;
		@FindBy(xpath ="//*[@id=\"DERIVED_ADDRESS_OK_PB$25$\"]")
		WebElement addressOKBtn;
		@FindBy(xpath ="//*[@id=\"win0divPSTOOLBAR\"]/span/a[1]")
		WebElement addrOKBtn;		
		@FindBy(xpath = "//*[@id=\"PERSONAL_PHONE_PHONE$0\"]")
		WebElement phoneNo;
		@FindBy(xpath ="//*[@id=\"PERSONAL_PHONE_PREF_PHONE_FLAG$0\"]")
		WebElement phoneCheck;
		@FindBy(xpath = "//*[@id=\"EMAIL_ADDRESSES_EMAIL_ADDR$0\"]")
		WebElement emailId;
		@FindBy(xpath = "//*[@id=\"EMAIL_ADDRESSES_PREF_EMAIL_FLAG$0\"]")
		WebElement emailCheck;
		@FindBy(xpath = "//*[@id=\"#ICPanel3\"]")
		WebElement orgRel;
		
		@FindBy(xpath = "//*[@id=\"DERIVED_HCR_PER_DERIVED_EMP\"]")
		WebElement EmployeeCheck;
		@FindBy(xpath = "//*[@id=\"DERIVED_HCR_PER_ADD_INSTANCE_LINK\"]")
		WebElement addRelBtn;
		
		//Method to navigate to add person
		public void navigate(String empId) {
			navBar.click();
			driver.switchTo().frame("psNavBarIFrame");
			sleep();
			menu.click();
			sleep();
			workAdmin.click();
			sleep();
			personalInfo.click();
			sleep();
			biographical.click();
			sleep();
			addNewPerson.click();
			sleep();
			driver.switchTo().frame("ptifrmtgtframe");
			personId.sendKeys(Keys.chord(Keys.CONTROL,"a"),Keys.DELETE,empId);
			clickOnAdd.click();
			sleep();
		}
		
		//Method to enter Biographical information of an employee
		public void biographicalInfo(String empName, String count) {
			effecDate.sendKeys(Keys.chord(Keys.CONTROL,"a"),Keys.DELETE,"01/01/2019");
			addNameBtn.click();
			driver.switchTo().defaultContent();
			sleep();
			driver.switchTo().frame("ptModFrame_0");
			firstName.sendKeys(empName);
			lastName.sendKeys(empName);
			okBtn.click();
			sleep();
			driver.switchTo().frame("ptifrmtgtframe");
			dob.sendKeys("01/25/2000");
			birth_country.sendKeys(Keys.chord(Keys.CONTROL,"a"),Keys.DELETE,"IND",Keys.ENTER);
			sleep();
			birth_state.sendKeys(Keys.chord("KA"),Keys.ENTER);
			sleep();
			birth_location.sendKeys("Bangalore");
			Select gender=new Select(driver.findElement(By.id("PERS_DATA_EFFDT_SEX$0")));
			gender.selectByVisibleText("Male");
			Select eduLevel=new Select(driver.findElement(By.id("PERS_DATA_EFFDT_HIGHEST_EDUC_LVL$0")));
			eduLevel.selectByIndex(1);
			Select mariStatus=new Select(driver.findElement(By.id("PERS_DATA_EFFDT_MAR_STATUS$0")));
			mariStatus.selectByVisibleText("Single");
			sleep();
			country.click();
			sleep();
			driver.switchTo().defaultContent();
			driver.switchTo().frame("ptModFrame_1");
			sleep();
			lookUpCntry.click();
			sleep();
			driver.switchTo().frame("ptifrmtgtframe");
			sleep();
			Select natIDtype=new Select(driver.findElement(By.xpath("//*[@id=\"PERS_NID_NATIONAL_ID_TYPE$0\"]")));
			sleep();
			natIDtype.selectByIndex(1);
			sleep();
			String PAN = (count + "PANABCD123").substring(0, 10);
			national_ID.sendKeys(PAN);
			sleep();
		}
		
		//Method to enter contact information of an employee
		public void contactInfo() {
			contact_Info.click();
			sleep();
			addr_Details.click();
			sleep();
			addr_country.sendKeys(Keys.chord(Keys.CONTROL,"a"),Keys.DELETE,"IND");
			add_Addr.click();
			sleep();
			address.sendKeys("White field");
			city.sendKeys("Bangalore");
			pincode.sendKeys("560066");
			state.sendKeys("KA");
			addressOKBtn.click();
			sleep();
			addrOKBtn.click();
			sleep();
			Select phoneType=new Select(driver.findElement(By.xpath("//*[@id=\"PERSONAL_PHONE_PHONE_TYPE$0\"]")));
			phoneType.selectByVisibleText("Main");
			sleep();
			phoneNo.sendKeys("9686504106");
			sleep();
			phoneCheck.click();
			sleep();
			Select emailType=new Select(driver.findElement(By.xpath("//*[@id=\"EMAIL_ADDRESSES_E_ADDR_TYPE$0\"]")));
			emailType.selectByVisibleText("Business");
			sleep();
			emailId.sendKeys("xyz@gmail.com");
			sleep();
			emailCheck.click();
			sleep();
			orgRel.click();
			sleep();
		}
		
		//Method to add organizational relationship
		public void orgRelDetails(){
			EmployeeCheck.click();
			sleep();
			Select checkListCode=new Select(driver.findElement(By.xpath("//*[@id=\"DERIVED_HCR_PER_CHECKLIST_CD\"]")));
			checkListCode.selectByIndex(2);
			sleep();
			addRelBtn.click();
			sleep();
		}
		
		public void addJobData () {
			
			//click on action under work location tab
				driver.findElement(By.xpath("//div[@id=\"win0divJOB_ACTION$0\"]/select")).click();
				sleep();
					
			//select the option jobHire
				WebElement jobhire=driver.findElement(By.xpath("//div[@id=\"win0divJOB_ACTION$0\"]/select/option[@value=\"HIR\"]"));
				jobhire.click();
				sleep();
					
			//select the reason 
				driver.findElement(By.xpath("//div[@id=\"win0divJOB_ACTION_REASON$0\"]/select")).click();
				sleep();
					
			//select reason as MX-Hire from drop down
				WebElement MXHire=driver.findElement(By.xpath("//div[@id=\"win0divJOB_ACTION_REASON$0\"]/select/option[@value=\"FIX\"]"));
				MXHire.click();
				sleep();
					
			//provide regulatory region
				driver.findElement(By.id("JOB_REG_REGION$0")).clear();
				driver.findElement(By.id("JOB_REG_REGION$0")).sendKeys("IND");
				sleep();
					
			//provide business unit
				driver.findElement(By.id("JOB_BUSINESS_UNIT$0")).clear();
				driver.findElement(By.id("JOB_BUSINESS_UNIT$0")).sendKeys("GBIBU");
				sleep();
					
			//provide department
				driver.findElement(By.id("JOB_DEPTID$0")).clear();
				driver.findElement(By.id("JOB_DEPTID$0")).sendKeys("12000");
				sleep();
					
			//provide location
				driver.findElement(By.id("JOB_LOCATION$0")).clear();
				driver.findElement(By.id("JOB_LOCATION$0")).sendKeys("KCAB00");
				sleep();
					
			//moving to job information tab
				driver.findElement(By.id("ICTAB_1")).click();
				sleep();
					
			//entering job code
				driver.findElement(By.id("JOB_JOBCODE$0")).clear();
				driver.findElement(By.id("JOB_JOBCODE$0")).sendKeys("110000");
				sleep();
					
			//entering option regular/temporary
				WebElement reg= driver.findElement(By.id("JOB_REG_TEMP$0"));
				reg.click();
				Select sel=new Select(reg);
				sel.selectByVisibleText("Regular");
				sleep();
					
			//selecting shift
				WebElement shift=driver.findElement(By.id("JOB_SHIFT$0"));
				shift.click();
				Select sel1=new Select(shift);
				sel1.selectByVisibleText("Any");
				sleep();
					
			//Full/Part time
				WebElement time=driver.findElement(By.id("JOB_FULL_PART_TIME$0"));
				time.click();
				Select sel2=new Select(time);
				sel2.selectByVisibleText("Full-Time");
				sleep();
					
			// Officer Code
				WebElement Offcode=driver.findElement(By.id("JOB_OFFICER_CD$0"));
				Offcode.click();
				Select sel3=new Select(Offcode);
				sel3.selectByVisibleText("Officer");
				sleep();
				
				
				
			// moving to payroll
				driver.findElement(By.id("ICTAB_3")).click();
			    sleep();
			    
			//  Clicking and selecting from payroll system
			    WebElement payroll_sys= driver.findElement(By.id("JOB_PAY_SYSTEM_FLG$0"));
			    payroll_sys.click();
			    Select pay=new Select (payroll_sys);
			    pay.selectByValue("GP");
			    sleep();

			//  Payroll system
			    driver.findElement(By.id("JOB_GP_PAYGROUP$30$$0")).clear();
			    driver.findElement(By.id("JOB_GP_PAYGROUP$30$$0")).sendKeys("K0L06MTH");
			    sleep();
			    
			    
			    
			 //	moving to Salary_plan
				driver.findElement(By.id("ICTAB_4")).click();
			    sleep();
			    
			//  Salary admin plan
			    driver.findElement(By.id("JOB_SAL_ADMIN_PLAN$0")).clear();
			    driver.findElement(By.id("JOB_SAL_ADMIN_PLAN$0")).sendKeys("K0G1");
			    sleep();
			    
			    
			    
			//moving to Compensation
				driver.findElement(By.id("ICTAB_5")).click();
			    sleep();
			    
			//  Rate code
			    driver.findElement(By.id("COMPENSATION_COMP_RATECD$0")).clear();
			    driver.findElement(By.id("COMPENSATION_COMP_RATECD$0")).sendKeys("BECAIN");
			    sleep();
			    
			//  Comp Rate
//			    driver.findElement(By.id("COMPENSATION_COMPRATE$0")).clear();
			    driver.findElement(By.id("COMPENSATION_COMPRATE$0")).sendKeys("1500");
			    sleep();
			    
//				Calculate button
				driver.findElement(By.id("DERIVED_HR_CMP_CALC_COMP_BTN$0")).click();
				
				
				
//				Clicking on save button
				driver.findElement(By.id("#ICSave")).click();
				sleep();
							
//				First popup
				driver.switchTo().defaultContent();
				driver.findElement(By.xpath("//*[@id=\"alertbutton\"]/a[1]")).click();
				sleep();
				
//				2nd popup
				driver.switchTo().defaultContent();
				driver.findElement(By.xpath("//*[@id=\"alertbutton\"]/a[1]")).click();
				sleep();
				
//				Saving data
				driver.switchTo().frame("ptifrmtgtframe");
				driver.findElement(By.id("#ICSave")).click();
				sleep();
				
		}
		
}
