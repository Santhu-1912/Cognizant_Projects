package pageClasses;

import utils.Waits;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class AssignWorkSchedule extends Waits{
	
	WebDriver driver;
	
	
	public AssignWorkSchedule(WebDriver driver){
		this.driver = driver;
	}
	
	//PageObjects
	By NavBar = By.id("PT_NAVBAR$IMG");
	By Menu = By.id("grouplet_PTNB$PTNUI_NB_MENU");
	By MSS = By.linkText("Manager Self Service");
	By TimeManagement = By.linkText("Time Management");
	By ManageSchedules = By.linkText("Manage Schedules");
	By AssignWorkSchedule = By.linkText("Assign Work Schedule");
	By Search = By.id("#ICSearch");
	By EmpIdSlot = By.id("SCH_EMPLMT_SRCH_EMPLID");
	By Calender = By.id("EFFDT$prompt$img$0");
	By currentDate = By.xpath("//a[contains(text(),'Current Date')]");
	By assignmentMethod = By.id("USE_DFLT_WS$0");
	By scheduleGroupLookUp = By.id("SCHEDULE_GRP$prompt$img$0");
	By scheduleIdLookUp = By.id("SCHEDULE_ID$prompt$img$0");
	By save = By.id("#ICSave");
	
	
	//Methods
	public void navigateToAssignWorkSchedule() {
		driver.findElement(NavBar).click();
		sleep();
		driver.switchTo().frame("psNavBarIFrame");
		driver.findElement(Menu).click();
		sleep();
		driver.findElement(MSS).click();
		sleep();
		driver.findElement(TimeManagement).click();
		sleep();
		driver.findElement(ManageSchedules).click();
		sleep();
		driver.findElement(AssignWorkSchedule).click();
	}
	
	public void openWorkSchedule(String empId) {
		sleep();
		driver.switchTo().frame("ptifrmtgtframe");
		//Searching the employee instance
		driver.findElement(EmpIdSlot).sendKeys(empId);
		sleep();
		//Selecting correct history
		if(!driver.findElement(By.id("#ICCorrectHistory")).isSelected()){
			driver.findElement(By.id("#ICCorrectHistory")).click();
		}
		sleep();
		driver.findElement(Search).click();
	}
	
	public void saveWorkSchedule(String schGroupId, String schId) {
		sleep();
		//Setting current date as Effective Date
		driver.findElement(Calender).click();
		sleep();
		driver.findElement(currentDate).click();
		sleep();
		
		//Selecting schedule
		Select select = new Select(driver.findElement(assignmentMethod));
		select.selectByVisibleText("Select Predefined Schedule");
		sleep();
		driver.findElement(scheduleGroupLookUp).click();
		sleep();
		driver.switchTo().defaultContent();
		driver.switchTo().frame("ptModFrame_0");
		driver.findElement(By.linkText(schGroupId)).click();
		sleep();
		driver.switchTo().frame("ptifrmtgtframe");
		driver.findElement(scheduleIdLookUp).click();
		sleep();
		driver.switchTo().defaultContent();
		driver.switchTo().frame("ptModFrame_1");
		driver.findElement(By.linkText(schId)).click();
		sleep();
		driver.switchTo().frame("ptifrmtgtframe");
		//Save
		driver.findElement(save).click();
	}
}
