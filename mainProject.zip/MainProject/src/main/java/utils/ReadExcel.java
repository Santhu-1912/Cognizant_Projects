package utils;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcel {
	
	private static String EmpName;
	private static String EmpId;
	private static String SchGrId;
	private static String SchId;
	private static String Count;
	
	private ReadExcel() {
	}
	public static void init(){
		String[] data = new String[5];
		FileInputStream fis;
		//Reading from excel and setting the values.
		try {
			fis = new FileInputStream(".\\src\\main\\resources\\Employee_Datasheet.xlsx");
			Workbook wb = new XSSFWorkbook(fis);
			Sheet s1 = wb.getSheetAt(0);
			Row r2 = s1.getRow(1);
			int i=0;
			for (i=0;i<5;i++) {
				Cell c_i = r2.getCell(i);
					data[i]=String.valueOf(c_i);
			}
			wb.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		ReadExcel.Count=data[0];
		ReadExcel.EmpName = data[1];
		ReadExcel.EmpId=data[2];
		ReadExcel.SchGrId=data[3];
		ReadExcel.SchId=data[4];
	}

	public static String getCount() {
		return Count;
	}

	public static String getEmpName() {
		return EmpName;
	}

	public static String getEmpId() {
		return EmpId;
	}

	public static String getSchGrId() {
		return SchGrId;
	}

	public static String getSchId() {
		return SchId;
	}
}
