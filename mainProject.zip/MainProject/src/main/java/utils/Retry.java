package utils;

import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

//This class returns false if max retry count(3) is reached, otherwise returns true
//This class ensures that when any test method fails it retries to run it upto 3 more times
public class Retry implements IRetryAnalyzer {	 
	  private int retryCount = 0;
	  private static final int maxRetryCount = 3;
	 
	  public boolean retry(ITestResult result) {
	    if (retryCount < maxRetryCount) {
	      retryCount++;
	      return true;
	    }
	    return false;
	  }
}

