package utils;

import java.io.File;
import java.io.IOException;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class screenshot {

	public static void saveScreenshot(WebDriver driver,String name) {
		//Taking Screenshot
		TakesScreenshot scrShot =((TakesScreenshot)driver);
		File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		//Format screenshot file name with timestamp.
		Date date = new Date();
		String d = date.toString().replaceAll(":","_").replaceAll(" ","_");
		//Saving Screenshot
		File DestFile=new File(".\\screenshots\\"+name+"_"+d+".png");
		try {
			FileUtils.copyFile(SrcFile, DestFile);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Screenshot not saved");
			e.printStackTrace();
		}
	}
}
