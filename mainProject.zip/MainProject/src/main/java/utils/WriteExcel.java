package utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class WriteExcel {

	public static void ExcelWrite(String Count) {
		
		Workbook wb = new XSSFWorkbook();
		Sheet s1 = wb.createSheet("Input_Data");
		
		//Setting header row
		Row r1 = s1.createRow(0);
		Cell c11 = r1.createCell(0);
		Cell c12 = r1.createCell(1);
		Cell c13 = r1.createCell(2);
		Cell c14 = r1.createCell(3);
		Cell c15 = r1.createCell(4);
		
		c11.setCellValue("Count");
		c12.setCellValue("Employee Name");
		c13.setCellValue("Employee Id");
		c14.setCellValue("Schedule Group Id");
		c15.setCellValue("Schedule Id");
		
		CellStyle style = wb.createCellStyle();
		style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
	    style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
		c11.setCellStyle(style);
		c12.setCellStyle(style);
		c13.setCellStyle(style);
		c14.setCellStyle(style);
		c15.setCellStyle(style);
		
		//Writing values
		Row r2 = s1.createRow(1);
		Cell c21 = r2.createCell(0);
		Cell c22 = r2.createCell(1);
		Cell c23 = r2.createCell(2);
		Cell c24 = r2.createCell(3);
		Cell c25 = r2.createCell(4);
		
		c21.setCellValue(Count);
		c22.setCellValue("Employee");
		c23.setCellValue("new_Emp_");
		c24.setCellValue("Sch_Gr_Id_");
		c25.setCellValue("Id_");
		
		s1.autoSizeColumn(0);
		s1.autoSizeColumn(1);
		s1.autoSizeColumn(2);
		s1.autoSizeColumn(3);
		s1.autoSizeColumn(4);
		FileOutputStream fos=null;
		try {
		    fos = new FileOutputStream(new File(".\\src\\main\\resources\\Employee_Datasheet.xlsx"));
		    System.out.println("Updated the excel file");
			wb.write(fos);
			wb.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Problem writing");
			e.printStackTrace();
		}
	}
}
