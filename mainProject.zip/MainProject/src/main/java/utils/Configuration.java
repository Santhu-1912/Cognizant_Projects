package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Configuration {
	/*Configuration class configures driver and url 
	 * according to value of properties read from properties file
	 */
	Properties props = new Properties();
	WebDriver driver;
	/*This default constructor loads url and driver name 
	 * from application.properties file in a Properties object.
	 * Then it initializes the correct webdriver by calling initDriver() method.
	 */
	public Configuration() {
		FileInputStream fis=null;
		try {
			fis = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\resources\\setUp.properties");
			props.load(fis);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//initDriver();
	}
	/* This method instantiate the correct webdriver
	 *  based on the value of property 'browser' and maximizes the window.
	 */
	public void initDriver() {
		String browser = props.getProperty("browser").toLowerCase();
		//instantiating driver based on value of property 'browser'.
		switch(browser) {
		case "chrome":
			driver = new ChromeDriver();
			break;
		case "firefox":
			driver = new FirefoxDriver();
			break;
		case "edge":
			driver = new EdgeDriver();
			break;
		default: 
			System.out.println("No valid driver defined. Defaulting to Edge");
			driver = new EdgeDriver();
			break;
		}
		//configure driver to maximize window.
		driver.manage().window().maximize();
		
	}
	
	/*getDriver() method returns the driver object.
	 */
	public WebDriver getDriver() {
		return driver;
	}
	/*returns the property value of 'base_url'
	 */
	public String getUrl() {
		return(props.getProperty("base_url"));
	}
	
}
