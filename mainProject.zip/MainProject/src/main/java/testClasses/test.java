package testClasses;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.WebDriverWait;

import pageClasses.AssignWorkSchedule;
import pageClasses.CreateSchedule;
import pageClasses.TnL_Enrollment;
import pageClasses.createEmployee;
import utils.Configuration;
import utils.ReadExcel;
import utils.Retry;
import utils.WriteExcel;
import utils.screenshot;

public class test {
	WebDriver driver;
	int count;
	String EmpName;
	String EmpId;
	String SchGrId;
	String SchId;
	Configuration config;
	String url;
	
	@BeforeClass
	public void Configure() {
		//retrieve driver with configuration from properties file using Configuration class object
		ReadExcel.init();
		count = Integer.valueOf(ReadExcel.getCount());
		EmpName = ReadExcel.getEmpName();
		EmpId = ReadExcel.getEmpId();
		SchGrId = ReadExcel.getSchGrId();
		SchId = ReadExcel.getSchId();
		config = new Configuration();
		url = config.getUrl();
	}
	
	@BeforeMethod
	public void login() {
		config.initDriver();
		driver = config.getDriver();
		//Navigating to the base_url
		driver.get(url);
		driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(20));
		driver.findElement(By.xpath("//*[contains(text(),'logon')]")).click();
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		WebDriverWait wait2 = new WebDriverWait(driver,Duration.ofSeconds(2));
		wait.until(ExpectedConditions.presenceOfElementLocated(By.name("Submit")));
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.name("Submit"))));
		driver.findElement(By.id("userid")).sendKeys("Training");
		driver.findElement(By.id("pwd")).sendKeys("Training");
		driver.findElement(By.name("Submit")).click();
		try {
			wait2.until(ExpectedConditions.alertIsPresent());
			driver.switchTo().alert().accept();
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	@AfterMethod
	public void close() {
		driver.quit();
	}
	@AfterSuite(alwaysRun=true)
	public void save() {
		WriteExcel.ExcelWrite(String.valueOf(count));
	}
	
	@Test(priority=1,enabled=true,retryAnalyzer = Retry.class)
	public void addEmployee() {
		count+=1;
		createEmployee emp = new createEmployee(driver);
		emp.navigate(EmpId+String.valueOf(count));
		emp.biographicalInfo(EmpName+String.valueOf(count),String.valueOf(count));
		emp.contactInfo();
		emp.orgRelDetails();
		emp.addJobData();
		screenshot.saveScreenshot(driver,"addEmployee");
	}
	
	@Test(priority=2,enabled=true,retryAnalyzer = Retry.class,dependsOnMethods = { "addEmployee"})
	public void Enrollment_TL() {
		TnL_Enrollment tnl = new TnL_Enrollment(driver);
		tnl.navigateToManageTimeReporterData();
		tnl.EnrollTimeReporter(EmpId+String.valueOf(count));
		screenshot.saveScreenshot(driver,"Enrollment_TL");
	}
	
	@Test(priority=3,enabled=true,retryAnalyzer = Retry.class,dependsOnMethods = { "addEmployee","Enrollment_TL"})
	public void schedule_Create() {
		CreateSchedule createSch = new CreateSchedule(driver);
		createSch.navigateToCreateWorkSchedule();
		createSch.define_Schedule(SchId+String.valueOf(count));
		createSch.set_Up_Schedules();
		screenshot.saveScreenshot(driver,"schedule_Create");
	}
	
	@Test(priority=4,enabled=true,retryAnalyzer = Retry.class,dependsOnMethods = { "addEmployee","Enrollment_TL","schedule_Create"})
	public void assignSchedule() {
		
		AssignWorkSchedule workSchedule = new AssignWorkSchedule(driver);
		
		workSchedule.navigateToAssignWorkSchedule();
		workSchedule.openWorkSchedule("K0G001");
		workSchedule.saveWorkSchedule("K0CYM","K0WRKSCH");
		screenshot.saveScreenshot(driver,"assignSchedule");
	}
}
