package com.selenium.reusableClasses;
//Import necessary libraries
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
public interface SetupFirefoxDriver {
public static WebDriver getFirefoxDriver() {
	    FirefoxOptions options=new FirefoxOptions();
	// create a new instance of FireFoxDriver with the options
	    options.addArguments("--start-maximized"); // Maximize the browser
		WebDriver driver = new FirefoxDriver(options);
		// maximize the window
		driver.manage().window().maximize();
		// return the driver instance
		return driver;
	}
}
