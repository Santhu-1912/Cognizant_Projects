package com.selenium.reusableClasses;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class WebElementLocator {
       private WebDriver driver;
       public void setDriver(WebDriver driver)
       {
    	   this.driver=driver;
       }
    // Find a web element by its ID
    public WebElement findById( String id) {
        return driver.findElement(By.id(id));
    }

    // Find a web element by its name
    public WebElement findByName( String name) {
        return driver.findElement(By.name(name));
    }

    // Find a web element by its class name
    public WebElement findByClassName( String className) {
        return driver.findElement(By.className(className));
    }

    // Find a web element by its tag name
    public WebElement findByTagName( String tagName) {
        return driver.findElement(By.tagName(tagName));
    }

    // Find a web element by its link text
    public WebElement findByLinkText( String linkText) {
        return driver.findElement(By.linkText(linkText));
    }

    // Find a web element by its partial link text
    public WebElement findByPartialLinkText( String partialLinkText) {
        return driver.findElement(By.partialLinkText(partialLinkText));
    }

    // Find a web element by its CSS selector
    public WebElement findByCssSelector( String cssSelector) {
        return driver.findElement(By.cssSelector(cssSelector));
    }

    // Find a web element by its XPath
    public WebElement findByXPath(WebDriver driver, String xpath) {
        return driver.findElement(By.xpath(xpath));
    }
}
