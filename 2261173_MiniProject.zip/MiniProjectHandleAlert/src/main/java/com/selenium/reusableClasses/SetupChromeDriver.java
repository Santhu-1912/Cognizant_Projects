package com.selenium.reusableClasses;

//Import necessary libraries
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public interface SetupChromeDriver {

    public static WebDriver getChromeDriver() {
        // Create an instance of ChromeOptions
        ChromeOptions options = new ChromeOptions();

        // Add some options to improve the performance of your tests
        options.addArguments("--start-maximized"); // Maximize the browser
        options.addArguments("--remote-allow-origins=*"); // Disable the "Chrome is being controlled by automated test software" message
        
        // Set up the ChromeDriver using the ChromeOptions
        WebDriver driver = new ChromeDriver(options);

       

        // Return the driver instance
        return driver;
    }
}
