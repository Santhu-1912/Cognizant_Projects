package com.selenium.reusableClasses;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;


public class Alerts  {
    private WebDriver driverAlerts;
    public void setDriverAlerts(WebDriver driverAlerts)
    {
    	this.driverAlerts=driverAlerts;
    }
    // Method to accept the alert
    public void acceptAlert() {
        Alert alert = driverAlerts.switchTo().alert();
        alert.accept();
    }

    // Method to dismiss the alert
    public void dismissAlert() {
        Alert alert = driverAlerts.switchTo().alert();
        alert.dismiss();
    }

    // Method to get the text of the alert
    public String getAlertText() {
        Alert alert = driverAlerts.switchTo().alert();
        return alert.getText();
    }

    // Method to send text to the alert
    public void sendTextToAlert(String text) {
        Alert alert = driverAlerts.switchTo().alert();
        alert.sendKeys(text);
    }
}
