package com.selenium.reusableClasses;

import java.awt.*;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.*;

public class Screenshot {
	
    public  Screenshot(String screenshot) {
        try {
            Robot robot = new Robot();
            Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
            BufferedImage image = robot.createScreenCapture(screenRect);

            String filepath = "./screenshots/" + screenshot + ".png"; // relative file path within the project directory
            File file = new File(filepath);
            ImageIO.write(image, "png", file);
        } catch (AWTException | IOException ex) {
            ex.printStackTrace();
        }
    }
}

