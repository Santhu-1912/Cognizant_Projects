package com.selenium.reusableClasses;
//Import necessary libraries
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
public interface SetupEdgeDriver {
public static WebDriver getEdgeDriver() {
	EdgeOptions options =new EdgeOptions();
	 options.addArguments("--start-maximized"); // Maximize the browser
	 // create a new instance of EdgeDriver with the options
		WebDriver driver = new EdgeDriver(options);
		
		
		// return the driver instance
		return driver;
	}
}
