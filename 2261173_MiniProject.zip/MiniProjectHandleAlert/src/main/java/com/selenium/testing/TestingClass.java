package com.selenium.testing;
//Import necessary libraries and Packages
import com.selenium.handlealerts.*;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import java.io.IOException;

public class TestingClass {
	@Test
        public void TestNgExcution() throws IOException {
	    //public static void main(String[] args) throws IOException,SocketException   {
		// Create instances of necessary classes
		SelectBrowser selectbrowser = new SelectBrowser();
		TestScenariosOfRediff testscenariosofrediff=new TestScenariosOfRediff();
		PropertiesClass propertiesclass=new PropertiesClass();
		/* 
		Get URL and browser drivers from properties file
		BROWSER DRIVERS:
		CHROME=propertiesclass.getChrome()  
		EDGE=propertiesclass.getEdge()  
		FIREFOX= propertiesclass.getFireFox
		 */
		 
		String URL=propertiesclass.getUrl();
		
		String BrowserName =propertiesclass.getEdge();
		// Selects appropriate driver based on the browser name
		WebDriver driver=selectbrowser.ChooseDriver(BrowserName);
		// Navigate to the URL and run the testing method
		driver.get(URL);
		//Calling testingMethod from TestScenariosOfRediff 
		testscenariosofrediff.testingMethod(driver);
		// Closes the Browser
		driver.quit();
	}
}
