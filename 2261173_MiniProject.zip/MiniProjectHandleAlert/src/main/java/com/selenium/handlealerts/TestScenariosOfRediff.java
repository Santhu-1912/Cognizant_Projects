package com.selenium.handlealerts;


// Import necessary libraries
import java.util.Set;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.testng.Assert;

import com.selenium.reusableClasses.Alerts;
import com.selenium.reusableClasses.Screenshot;
import com.selenium.reusableClasses.WebElementLocator;

// This class implements the Alerts interface and extends the WebElementLocator class
public class TestScenariosOfRediff extends WebElementLocator  {     
 
  // This method performs some test scenarios on the Rediff website
  public void testingMethod(WebDriver driver) {  
    	
    // Create an instance of the Alerts class
    Alerts alerts=new Alerts();
    
    // Set the WebDriver instance for the Alerts class
    alerts.setDriverAlerts(driver);
    // Set the WebDriver instance for the WebElementLocator class
    setDriver(driver); 
    
    // Click on the "Sign In" button without filling any information
    WebElement Sign_in=findByClassName("signin");
    Sign_in.click();
    
    // Get the text of the alert and verify whether the correct alert is displayed for the first scenario
    WebElement Sign_in1=findByName("proceed");
    
    Sign_in1.click();
    driver.switchTo().alert();
    String Signin_Alert_Text = alerts.getAlertText();
    Assert.assertEquals(Signin_Alert_Text, "Please enter a valid user name");
    System.out.println("1. SignInWithOutParametersTest: Fetch the text of the Alert and verify whether the correct alert is displayed.");
    System.out.println("   The Alert which was displayed is absolutely correct:\n   Alert Text = " + Signin_Alert_Text + "\n");
    
    // Accept the alert to close it

    alerts.acceptAlert();
    
    // Click on the "Forgot password" link
    WebElement forgot_Password=findByLinkText("Forgot Password?");
    forgot_Password.click();
    
    // Click on the "Next" button without filling any information
    WebElement Next =findByName("next");
    Next.click();
    
    // Get the text of the alert and verify whether the correct alert is displayed for the second scenario
    String ForgetPassword_alertText = alerts.getAlertText();
    Assert.assertEquals(ForgetPassword_alertText, "Please enter your email ID");
    System.out.println("2. ForgetPasswordWithOutInputTest: Fetch the text of the Alert and verify whether the correct alert is displayed.");
    System.out.println("   The Alert which was displayed is absolutely correct:\n   Alert Text = " + ForgetPassword_alertText + "\n");
    // Accept the alert to close it
    alerts.acceptAlert();
    
    // Navigate back to the webpage
    driver.navigate().back();
    
    // Click on the "Privacy Policy" link and verify whether the respective page is displayed in a new tab
    WebElement Privacy_policy=findByLinkText("Privacy Policy");
    Privacy_policy.click();
    String currentWindowhandle =driver.getWindowHandle();
    Set<String> allWindowHandles =  driver.getWindowHandles();
    for(String i:allWindowHandles)
    {
    	if(!i.equals(currentWindowhandle))
    		driver.switchTo().window(i);
    		
    }
    // Instance of Screenshot class to take screenshot
    Screenshot s3=new Screenshot("privacy&policy");
    System.out.println("3. WindowHandleTest: Verify whether the respective page is displayed in a new tab.");
    //Ternary operator  check whether the respective page is displayed in a new tab
    String Test3=(allWindowHandles.size() == 1)?"  The page 'Privacy Policy' is displayed in the same tab.":"   The page 'Privacy Policy' is displayed in another tab.";
    System.out.println(Test3);
    
    // Close the current browser window
    driver.close();
  }
}
