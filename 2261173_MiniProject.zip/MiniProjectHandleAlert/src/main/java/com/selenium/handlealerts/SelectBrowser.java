package com.selenium.handlealerts;

// Import necessary libraries
import org.openqa.selenium.WebDriver;

import com.selenium.reusableClasses.SetupChromeDriver;
import com.selenium.reusableClasses.SetupEdgeDriver;
import com.selenium.reusableClasses.SetupFirefoxDriver;

/*
 This class implements the SetupChromeDriver, SetupEdgeDriver, SetupFirefoxDriver interfaces to
 choose the appropriate web driver based on the browser name.
 */
public class SelectBrowser implements SetupChromeDriver, SetupEdgeDriver, SetupFirefoxDriver {
    
    /*
      Chooses the appropriate web driver based on the given browser name.
      parameter Browsername = browser name in which we run our tests
      returnType = the particular browser According to input
     */
    public WebDriver ChooseDriver(String Browsername) {
        // Switch operation to choose the appropriate web driver based on the given browser name.
        switch (Browsername) {
            case "CHROME"  : return SetupChromeDriver.getChromeDriver();
            case "EDGE"    : return SetupEdgeDriver.getEdgeDriver();
            default        : return SetupFirefoxDriver.getFirefoxDriver();
        }
    }
}
