package com.selenium.handlealerts;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class PropertiesClass {
	
    private FileInputStream fileInputStream;
    private Properties properties;

    // Constructor that initializes file input stream and loads properties from file
    public PropertiesClass() throws IOException {
        // Initialize file input stream to read from properties file
        fileInputStream = new FileInputStream("./confug.properties");
        // Initialize Properties object and load the properties from the file input stream
        properties = new Properties();
        properties.load(fileInputStream);
    }

    // Getter method for URL property in properties file
    public String getUrl() {
        return properties.getProperty("Browser_Url");
    }

    // Getter method for Chrome driver property in properties file
    public String getChrome() {
        return properties.getProperty("browser_Chrome");
    }

    // Getter method for Edge driver property in properties file
    public String getEdge() {
        return properties.getProperty("browser_Edge");
    }

    // Getter method for Firefox driver property in properties file
    public String getFireFox() {
        return properties.getProperty("browser_FireFox");
    }
}
