package PageClasses;

import java.net.SocketException;
import java.util.NoSuchElementException;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import UtilityClasses.CommonUtils;
import UtilityClasses.LoggerUtils;
import UtilityClasses.ReportUtils;

public class CruiseHolidayDealsPage extends CommonUtils {

	public static void CruisesPage() {
		LoggerUtils.info(CommonUtils.getValue("L12"));
		ReportUtils.startTest("Test case 12", CommonUtils.getValue("TC_12"));

		try {
			driver.navigate().to(getValue("cruiseShip_url"));
			ReportUtils.logInfo(CommonUtils.getValue("TC_12_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_12_P"));
			LoggerUtils.info(CommonUtils.getValue("LO12"));
		} catch ( StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_12_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug1"));
			ReportUtils.setSeverity(CommonUtils.getValue("h"));

		}

	}

	public static void CruiseShipButton() {
		LoggerUtils.info(CommonUtils.getValue("L13"));
		ReportUtils.startTest("Test case 13", CommonUtils.getValue("TC_13"));

		try {
			WebElement CruiseShip = XPath("CruiseShip_Xpath");
			waitForElementVisible(CruiseShip);
			Assert.assertFalse(CruiseShip.isEnabled());
			ReportUtils.logInfo(CommonUtils.getValue("TC_13_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_13_P"));
			LoggerUtils.info(CommonUtils.getValue("LO13"));
		} catch (StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_13_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}

	}

	public static void SearchButton() {
		LoggerUtils.info(CommonUtils.getValue("L14"));
		ReportUtils.startTest("Test case 14", CommonUtils.getValue("TC_14"));

		try {
			WebElement Search = XPath("Search_Xpath");
			waitForElementVisible(Search);
			Assert.assertFalse(Search.isEnabled());
			ReportUtils.logInfo(CommonUtils.getValue("TC_14_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_14_P"));
			LoggerUtils.info(CommonUtils.getValue("LO14"));
		} catch ( StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_14_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}
	}

	public static void ListButtonCruiseLine() {
		LoggerUtils.info(CommonUtils.getValue("L15"));
		ReportUtils.startTest("Test case 15", CommonUtils.getValue("TC_15"));
		try {
			WebElement CruiseLine = XPath("CruiseLine_Xpath");
			waitForElementVisible(CruiseLine);
			CruiseLine.click();
			WebElement list = XPath("CruiseLine_List_Xpath");
			waitForElementVisible(list);
			Assert.assertTrue(list.getCssValue("display").equals("block"));
			WebElement line = XPath("Norwegian_Cruise_Line_Xpath");
			line.click();
			ReportUtils.logInfo(CommonUtils.getValue("TC_15_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_15_P"));
			LoggerUtils.info(CommonUtils.getValue("LO15"));
		} catch (StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_15_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));
		}

	}

	public static void ListButtonCruiseShip() {
		LoggerUtils.info(CommonUtils.getValue("L16"));
		ReportUtils.startTest("Test case 16", CommonUtils.getValue("TC_16"));

		try {
			WebElement CruiseShip = XPath("CruiseShip_Xpath");
			waitForElementVisible(CruiseShip);
			CruiseShip.click();
			WebElement list = XPath("CruiseShipList_Xpath");
			waitForElementVisible(list);
			Assert.assertTrue(list.getCssValue("display").equals("block"));
			WebElement ship = XPath("Norwegian_Epic_Xpath");
			waitForElementVisible(ship);
			ship.click();
			ReportUtils.logInfo(CommonUtils.getValue("TC_16_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_16_P"));
			LoggerUtils.info(CommonUtils.getValue("LO16"));
		} catch ( StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_16_F"));
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}
	}

	public static void ElementsClickable() throws InterruptedException {
		LoggerUtils.info(CommonUtils.getValue("L17"));
		ReportUtils.startTest("Test case 17", CommonUtils.getValue("TC_17"));

		try {
			Thread.sleep(3000);
			CommonUtils.takeScreenshot("CruiseHolidayDealsPage");
			WebElement Search = XPath("Search_Xpath");
			waitForElementClickable(Search);
			Actions actions = new Actions(driver);
			actions.click(Search).build().perform();
			Assert.assertTrue(Search.isEnabled());
			ReportUtils.logInfo(CommonUtils.getValue("TC_17_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_17_P"));
			LoggerUtils.info(CommonUtils.getValue("LO17"));
		} catch (StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_17_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug1"));
			ReportUtils.setSeverity(CommonUtils.getValue("m"));

		}
	}

}
