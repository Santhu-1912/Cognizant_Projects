package PageClasses;

import java.util.NoSuchElementException;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import UtilityClasses.CommonUtils;
import UtilityClasses.ReadExcelutils;
import UtilityClasses.LoggerUtils;
import UtilityClasses.ReportUtils;

public class TripAdvisorHomePage extends CommonUtils {

	public static void LandingMainPage() {
		LoggerUtils.info(CommonUtils.getValue("L0"));
		ReportUtils.startTest("Test case 0", CommonUtils.getValue("TC_0"));
		try {
			driver.manage().window().maximize();
			driver.get(getValue("LandingPage_url"));
			Assert.assertEquals(driver.getTitle(), getValue("Landingpage_Title"));
			ReportUtils.logInfo(CommonUtils.getValue("TC_0_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_0_P"));
			LoggerUtils.info(CommonUtils.getValue("LO0"));
		} catch (StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_0_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug1"));
			ReportUtils.setSeverity(CommonUtils.getValue("H"));
		}
	}

	public static void HolidayHomes() throws InterruptedException {
		LoggerUtils.info(CommonUtils.getValue("L2"));
		ReportUtils.startTest("Test case 2", CommonUtils.getValue("TC_2"));

		try {
			WebElement HolidayHomes = XPath("HolidayHome_Xpath");
			waitForElementClickable(HolidayHomes);
			HolidayHomes.click();
			WebElement Search = XPath("Search_Where_To_Xpath");
			waitForElementVisible(Search);

			String Destination = ReadExcelutils.getCellData(2, 0);
			Search.sendKeys(Destination);
			Thread.sleep(3000);
			CommonUtils.takeScreenshot("TripAdvisorHomePage");
			WebElement AjexCall = XPath("AjexCallNairobi_Xpath");
			waitForElementVisible(AjexCall);
			AjexCall.click();
			Assert.assertEquals(driver.getTitle(), getValue("HolidayHomesPage_Title"));
			ReportUtils.logInfo(CommonUtils.getValue("TC_2_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_2_P"));
			LoggerUtils.info(CommonUtils.getValue("LO2"));
		} catch (StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_2_F"));
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}
	}

}
