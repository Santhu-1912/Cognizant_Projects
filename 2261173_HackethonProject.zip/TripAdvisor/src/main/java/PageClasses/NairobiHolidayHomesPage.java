package PageClasses;

import java.io.IOException;
import java.net.SocketException;
import java.util.NoSuchElementException;
import java.util.Map;
import java.util.HashMap;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

import UtilityClasses.CommonUtils;
import UtilityClasses.DateUtils;
import UtilityClasses.LoggerUtils;
import UtilityClasses.ReportUtils;
import UtilityClasses.WriteExcelUtils;
public class NairobiHolidayHomesPage extends CommonUtils {
	public static String Hotel1, Hotel2, Hotel3, H1CostPerNight, H2CostPerNight, H3CostPerNight, H1TotalCost,
			H2TotalCost, H3TotalCost;
	public static void dateButton() throws InterruptedException {
		LoggerUtils.info(CommonUtils.getValue("L3"));
		ReportUtils.startTest("Test case 3", CommonUtils.getValue("TC_3"));

		try {
			Actions actions = new Actions(driver);
			actions.scrollByAmount(200, 200).perform();
			WebElement date = XPath("Dates_Xpath");
			waitForElementClickable(date);
			date.click();
			Thread.sleep(1000);
			WebElement CheckIn = DateUtils.CheckInDate();
			waitForElementClickable(CheckIn);
			CheckIn.click();
			WebElement CheckOut = DateUtils.CheckOutDate();
			waitForElementClickable(CheckOut);
            
			CheckOut.click();
			waitForElementVisible(date);
			Assert.assertEquals(date.getText(), DateUtils.ExpectedDate());
			ReportUtils.logInfo(CommonUtils.getValue("TC_3_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_3_P"));
			LoggerUtils.info(CommonUtils.getValue("LO3"));
		} catch ( StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_3_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}
	}

	public static void Elevator() throws InterruptedException {
		LoggerUtils.info(CommonUtils.getValue("L4"));
		ReportUtils.startTest("Test case 4", CommonUtils.getValue("TC_4"));

		try {
			WebElement Showall_Ameneties = XPath("AmenitiesShowAll_Xpath");
			Showall_Ameneties.click();
			WebElement Lift = XPath("Lift/Elevator_Xpath");
			waitForElementClickable(Lift);
			Lift.click();
			WebElement apply = XPath("ApplyButton_Xpath");
			apply.click();
			ReportUtils.logInfo(CommonUtils.getValue("TC_4_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_4_P"));
			LoggerUtils.info(CommonUtils.getValue("LO4"));
		} catch (StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_4_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}

	}

	public static void TravelRating() {
		LoggerUtils.info(CommonUtils.getValue("L5"));
		ReportUtils.startTest("Test case 5", CommonUtils.getValue("TC_5"));

		try {
			WebElement Sort = XPath("Sorting_Xpath");
			Sort.click();
			WebElement TravellerRating = XPath("TravellerRating_Xpath");
			TravellerRating.click();
			String text = Sort.getText();
			Assert.assertEquals(text, "Traveller Rating");
			ReportUtils.logInfo(CommonUtils.getValue("TC_5_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_5_P"));
			LoggerUtils.info(CommonUtils.getValue("LO5"));
		} catch ( StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_5_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}
	}

	public static void Guests() {
		LoggerUtils.info(CommonUtils.getValue("L16"));
		ReportUtils.startTest("Test case 6", CommonUtils.getValue("TC_6"));

		try {
			WebElement guests = XPath("GuestsButton_Xpath");
			guests.click();
			WebElement GustsIntialCount = XPath("GuestsCount_Xpath");
			String countString = GustsIntialCount.getText();
			int count = Integer.parseInt(countString);

			WebElement guestPlus = XPath("GuestsPlus_Xpath");
			for (int i = count; i < 4; i++) {
				guestPlus.click();
			}
			WebElement guestsApply = XPath("GuestApplyButton_Xpath");
			String countString1 = GustsIntialCount.getText();
			guestsApply.click();
			Assert.assertEquals(countString1, "4");
			ReportUtils.logInfo(CommonUtils.getValue("TC_6_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_6_P"));
			LoggerUtils.info(CommonUtils.getValue("LO6"));
			 Thread.sleep(3000);
		} catch (InterruptedException|StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_6_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}
	}

	public static void PerNightCost() throws InterruptedException, IOException {
		LoggerUtils.info(CommonUtils.getValue("L8"));
		ReportUtils.startTest("Test case 8", CommonUtils.getValue("TC_8"));

		try {
			WebElement Hotel_1 = XPath("HotelONEPerNight_Xpath");
			waitForElementVisible(Hotel_1);
			WebElement Hotel_2 = XPath("HotelTWOPerNight_Xpath");
			waitForElementVisible(Hotel_2);
			WebElement Hotel_3 = XPath("HotelThreePerNight_Xpath");
			waitForElementVisible(Hotel_3);
			H1CostPerNight = Hotel_1.getText();
			H2CostPerNight = Hotel_2.getText();
			H3CostPerNight = Hotel_3.getText();
			

			Assert.assertTrue(Hotel_1.isDisplayed());
			ReportUtils.logInfo(CommonUtils.getValue("TC_8_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_8_P"));
			LoggerUtils.info(CommonUtils.getValue("LO8"));
		} catch (StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_8_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}
	}

	public static void TotalCost() throws IOException {
		LoggerUtils.info(CommonUtils.getValue("L9"));
		ReportUtils.startTest("Test case 9", CommonUtils.getValue("TC_9"));

		try {
			WebElement Hotel_1 = XPath("HotelONETotal_Xpaths");
			waitForElementVisible(Hotel_1);
			WebElement Hotel_2 = XPath("HotelTWOTotal_Xpaths");
			waitForElementVisible(Hotel_2);
			WebElement Hotel_3 = XPath("HotelThreeTotal_Xpath");
			waitForElementVisible(Hotel_3);
			H1TotalCost = Hotel_1.getText();
			H2TotalCost = Hotel_2.getText();
			H3TotalCost = Hotel_3.getText();
			Assert.assertTrue((Hotel_1.getText()).contains(getValue("TotalCost")));
			ReportUtils.logInfo(CommonUtils.getValue("TC_9_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_9_P"));
			LoggerUtils.info(CommonUtils.getValue("LO9"));
		} catch (StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_9_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}
	}

	public static void HotelNames() throws InterruptedException, IOException {
		LoggerUtils.info(CommonUtils.getValue("L7"));
		ReportUtils.startTest("Test case 7", CommonUtils.getValue("TC_7"));

		try {
			Actions actions = new Actions(driver);
			actions.scrollByAmount(200, 300).perform();
			CommonUtils.takeScreenshot("NairobiHolidayHomesPage");
			WebElement Hotel_1 = XPath("HotelOne_Xpath");
			waitForElementVisible(Hotel_1);
			WebElement Hotel_2 = XPath("HotelTwo_Xpath");
			waitForElementVisible(Hotel_2);
			WebElement Hotel_3 = XPath("HotelThree_Xpath");
			waitForElementVisible(Hotel_3);
			Hotel1 = Hotel_1.getText();
			Hotel2 = Hotel_2.getText();
			Hotel3 = Hotel_3.getText();
			Assert.assertTrue(Hotel_1.isDisplayed());
			ReportUtils.logInfo(CommonUtils.getValue("TC_7_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_7_P"));
			LoggerUtils.info(CommonUtils.getValue("LO7"));
		} catch (StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_7_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}
		

	}
	 public static Map<Integer, String[]> createMap() {
		 Map<Integer, String[]> HolidayHomes = new HashMap<Integer, String[]>();
			String[] array1= {Hotel1,H1CostPerNight,H1TotalCost};
			String[] array2= {Hotel2,H2CostPerNight,H2TotalCost};
			String[] array3= {Hotel3,H3CostPerNight,H3TotalCost};
			HolidayHomes.put(1,array1);
			HolidayHomes.put(2,array2);
			HolidayHomes.put(3,array3);
	        return HolidayHomes;
	    }
	
}
