package PageClasses;

import java.net.SocketException;
import java.util.NoSuchElementException;
import java.util.Set;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import UtilityClasses.CommonUtils;
import UtilityClasses.LoggerUtils;
import UtilityClasses.ReportUtils;

public class FirstSearchResultHotelPage extends CommonUtils {

	public static void HotelDetails() throws InterruptedException {
		LoggerUtils.info(CommonUtils.getValue("L10"));
		ReportUtils.startTest("Test case 10", CommonUtils.getValue("TC_10"));

		try {

			Actions actions = new Actions(driver);
			try {
				WebElement hotelLink = XPath("FirstLink_Xpath");
				waitForElementClickable(hotelLink);
				actions.click(hotelLink).build().perform();
			} catch ( StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
				WebElement hotelLink1 = XPath("HotelTwo_Xpath");
				waitForElementClickable(hotelLink1);
				actions.click(hotelLink1).build().perform();

			}

			String MainWindow = driver.getWindowHandle();
			Set<String> allWindows = driver.getWindowHandles();
			for (String i : allWindows) {
				if (!MainWindow.equals(i)) {
					driver.switchTo().window(i);
				}
			}
			ReportUtils.logInfo(CommonUtils.getValue("TC_10_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_10_P"));
			LoggerUtils.info(CommonUtils.getValue("LO10"));
		} catch ( StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_10_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}
	}

	public static void Availability() throws InterruptedException {
		LoggerUtils.info(CommonUtils.getValue("L1"));
		ReportUtils.startTest("Test case 11", CommonUtils.getValue("TC_11"));

		try {
			Thread.sleep(4000);
			CommonUtils.takeScreenshot("FirstSearchResultHotelPage");
			WebElement Availabilty = XPath("Availability_Xpath");

			waitForElementVisible(Availabilty);
			Assert.assertTrue((Availabilty.getText()).contains(getValue("Availability")));
			ReportUtils.logInfo(CommonUtils.getValue("TC_11_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_11_P"));
			LoggerUtils.info(CommonUtils.getValue("LO11"));
		} catch ( StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_11_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}

	}

}
