package PageClasses;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import UtilityClasses.CommonUtils;
import UtilityClasses.LoggerUtils;
import UtilityClasses.ReportUtils;
import UtilityClasses.WriteExcelUtils;

public class NorwegianEpicShipPage extends CommonUtils {
	public static String Passengers, Crew, Launchedyear;

	public static void ViewElementsOne() {
		LoggerUtils.info(CommonUtils.getValue("L18"));
		ReportUtils.startTest("Test case 18", CommonUtils.getValue("TC_18"));

		try {
			Thread.sleep(1000);
			CommonUtils.takeScreenshot("NorwegianEpicShipPage");
			Actions actions = new Actions(driver);
			actions.scrollByAmount(200, 650).perform();
			String MainWindow = driver.getWindowHandle();
			Set<String> allWindows = driver.getWindowHandles();
			for (String i : allWindows) {
				if (!MainWindow.equals(i)) {
					driver.switchTo().window(i);
				}
			}
			WebElement crew = XPath("Passengers&Crew_Xpath");
			waitForElementVisible(crew);
			String ref = crew.getText();
			String[] parts = ref.split("\\|");
			Passengers = parts[0].trim();
			Crew = parts[1].trim();

			WebElement year = XPath("Launchedyear_Xpath");
			waitForElementVisible(year);
			String ref1 = year.getText();
			String[] parts1 = ref1.split("\\|");
			Launchedyear = parts1[0].trim();
			ReportUtils.logInfo(CommonUtils.getValue("TC_18_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_18_P"));
			LoggerUtils.info(CommonUtils.getValue("LO18"));
		} catch (InterruptedException | StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_18_F"));
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}

	}

	public static void ViewElementsTwo() throws InterruptedException, IOException {
		LoggerUtils.info(CommonUtils.getValue("L19"));
		ReportUtils.startTest("Test case 19", CommonUtils.getValue("TC_19"));
		try {
			Actions actions = new Actions(driver);
			actions.scrollByAmount(200, 1550).perform();
			Thread.sleep(2000);
			WebElement more = XPath("More_Xpath");
			waitForElementClickable(more);
			more.click();
			Thread.sleep(2000);
			WebElement Languages = XPath("Languages_Xpath");
			waitForElementVisible(Languages);
			String g = Languages.getText();
			String cleanedString = g.replaceAll("\\(\\d+\\)", "");
			String[] languages = cleanedString.split("\\s+");
    
			Map<Integer, String[]> Cruises = new HashMap<Integer, String[]>();
			String lang="";
			for (String language : languages) {
				if (!language.equals("All") && !language.equals("languages"))
				{
					lang+=language+" ";
				}
			}
			String[] array= {"Norwegian Epic",Crew,Passengers,Launchedyear,lang};
			Cruises.put(1, array);
			
			WriteExcelUtils.createWorkbook(NairobiHolidayHomesPage.createMap(),Cruises);
			ReportUtils.logInfo(CommonUtils.getValue("TC_19_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_19_P"));
			LoggerUtils.info(CommonUtils.getValue("LO19"));
		} catch (StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log"),e);
			ReportUtils.logFail(CommonUtils.getValue("TC_19_F") );
			ReportUtils.addBugReport(CommonUtils.getValue("bug2"));
			ReportUtils.setSeverity(CommonUtils.getValue("l"));

		}
	}

}
