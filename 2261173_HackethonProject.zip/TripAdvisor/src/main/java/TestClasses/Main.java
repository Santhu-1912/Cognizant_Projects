package TestClasses;

import java.io.IOException;

import org.testng.annotations.Test;

import PageClasses.CruiseHolidayDealsPage;
import PageClasses.FirstSearchResultHotelPage;
import PageClasses.NairobiHolidayHomesPage;
import PageClasses.NorwegianEpicShipPage;
import PageClasses.TripAdvisorHomePage;
import BaseClasses.BrowserFactory;
import ErrorHandling.InvalidSearch;



public class Main extends BrowserFactory {
    /**  Landing on the TripAdvisor home page **/
	@Test(priority = 0, groups = { "Smoke Testing" })
	public void zeroTestCase() throws IOException {
		TripAdvisorHomePage.LandingMainPage();
	}
	/** Testing for an invalid search **/
	@Test(priority = 1, groups = { "Regression Testing" }, dependsOnMethods = { "zeroTestCase" })
	public void firstTestCase() throws Exception {
		InvalidSearch.InvalidValue();
	}
	/** Navigating to the holiday homes page **/
	@Test(priority = 2, groups = { "Regression Testing ", "Smoke Testing" }, dependsOnMethods = { "zeroTestCase" })
	public void secondTestCase() throws IOException, InterruptedException {

		TripAdvisorHomePage.HolidayHomes();
	}
	/** Testing date selection functionality **/
	@Test(priority = 3, groups = { "Regression Testing " }, dependsOnMethods = { "secondTestCase" })
	public void thirdTestCase() throws IOException, InterruptedException {

		NairobiHolidayHomesPage.dateButton();
	}
	/** Testing functionality of elevators in holiday homes **/
	@Test(priority = 4, groups = { "Regression Testing " }, dependsOnMethods = { "secondTestCase" })
	public void fourthTestCase() throws IOException, InterruptedException {

		NairobiHolidayHomesPage.Elevator();
	}
	/** Testing the travel rating feature **/
	@Test(priority = 5, groups = { "Regression Testing " }, dependsOnMethods = { "secondTestCase" })
	public void fifthTestCase() throws IOException {

		NairobiHolidayHomesPage.TravelRating();
	}
	/** Testing functionality of guest capacity selection **/
	@Test(priority = 6, groups = { "Regression Testing " }, dependsOnMethods = { "secondTestCase" })
	public void sixthTestCase() throws IOException {

		NairobiHolidayHomesPage.Guests();
	}
	/** Testing the display of hotel names **/
	@Test(priority = 7, groups = { "Regression Testing " }, dependsOnMethods = { "secondTestCase" })
	public void seventhTestCase() throws IOException, InterruptedException {

		NairobiHolidayHomesPage.HotelNames();
	}
	/** Testing the display of hotel price per night **/
	@Test(priority = 8, groups = { "Regression Testing " }, dependsOnMethods = { "secondTestCase" })
	public void eigthTestCase() throws IOException, InterruptedException {

		NairobiHolidayHomesPage.PerNightCost();
	}
	/** Testing the display of hotel total price **/
	@Test(priority = 9, groups = { "Regression Testing " }, dependsOnMethods = { "secondTestCase" })
	public void ninthTestCase() throws IOException {

		NairobiHolidayHomesPage.TotalCost();
	}
	/** Testing the display functionality of particular hotel **/
	@Test(priority = 10, groups = { "Regression Testing " }, dependsOnMethods = { "secondTestCase" })
	public void TengthTestCase() throws IOException, InterruptedException {

		FirstSearchResultHotelPage.HotelDetails();
	}
	/** Testing the display of availability of hotel on particular dates **/
	@Test(priority = 11, groups = { "Regression Testing " }, dependsOnMethods = { "TengthTestCase" })
	public void eleventhTestCase() throws IOException, InterruptedException {

		FirstSearchResultHotelPage.Availability();
	}
	/**  Testing the functionality cruises Page **/
	@Test(priority = 12, groups = { "Regression Testing ", " Smoke testing" })
	public void twelfthTestCase() throws IOException {

		CruiseHolidayDealsPage.CruisesPage();
	}
	/**  Testing the functionality of list Button **/
	@Test(priority = 13, groups = { "Regression Testing " }, dependsOnMethods = { "twelfthTestCase" })
	public void thirteenthTestCase() throws IOException {

		CruiseHolidayDealsPage.CruiseShipButton();
	}
	/**  Testing the functionality of  Element **/
	@Test(priority = 14, groups = { "Regression Testing " }, dependsOnMethods = { "twelfthTestCase" })
	public void fourteenthTestCase() throws IOException {

		CruiseHolidayDealsPage.SearchButton();
	}
	/**  Testing the functionality of list Button **/
	@Test(priority = 15, groups = { "Regression Testing " }, dependsOnMethods = { "twelfthTestCase" })
	public void fifteenthTestCase() throws IOException {

		CruiseHolidayDealsPage.ListButtonCruiseLine();
	}
	/** Testing the functionality of list Button  **/
	@Test(priority = 16, groups = { "Regression Testing " }, dependsOnMethods = { "twelfthTestCase" })
	public void sixteenthTestCase() throws IOException {

		CruiseHolidayDealsPage.ListButtonCruiseShip();
	}
	/** Testing the functionality of search **/
	@Test(priority = 17, groups = { "Regression Testing " }, dependsOnMethods = { "twelfthTestCase" })
	public void seventeenthTestCase() throws IOException, InterruptedException {

		CruiseHolidayDealsPage.ElementsClickable();
	}
	/** Testing The display function (crew,launched year)  **/
	@Test(priority = 18, groups = { "Regression Testing " }, dependsOnMethods = { "seventeenthTestCase" })
	public void eighteenthTestCase() throws IOException {

		NorwegianEpicShipPage.ViewElementsOne();
	}
	/** Testing The display function (languages Offerd) **/
	@Test(priority = 19, groups = { "Regression Testing " }, dependsOnMethods = { "seventeenthTestCase" })
	public void nineteenthTestCase() throws IOException, InterruptedException {

		NorwegianEpicShipPage.ViewElementsTwo();
	}
}
