package UtilityClasses;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.Layout;
import org.apache.logging.log4j.core.config.Configurator;
import org.testng.annotations.Test;

/**
 * Initializes Log4j2 configuration from the specified XML file.
 */
public class LoggerUtils {
	
    private static final Logger logger = LogManager.getLogger(LoggerUtils.class);
    public LoggerUtils() {
    	Configurator.initialize(null, "./log4j2.xml");
	}
    
    public static void trace(String message) {
        logger.trace(message);
    }

    public static void debug(String message) {
        logger.debug(message);
    }

    public static void info(String message) {
        logger.info(message);
    }

    public static void warn(String message) {
        logger.warn(message);
    }

    public static void error(String message, Throwable throwable) {
        logger.error(message, throwable);
      }

    public static void fatal(String message) {
        logger.fatal(message);
    }
}

