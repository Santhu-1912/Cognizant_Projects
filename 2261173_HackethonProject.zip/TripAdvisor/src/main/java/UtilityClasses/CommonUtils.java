package UtilityClasses;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import BaseClasses.BrowserFactory;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;

public class CommonUtils extends BrowserFactory {
	private static FileInputStream propertiesFile, ExcelInputFile;
	private static Properties prop;

	/*** Constructor for to intilize some methods before starting main class **/
	public CommonUtils() {

		try {
			propertiesFile = new FileInputStream("./src/main/resources/config.properties");
			ExcelInputFile = new FileInputStream(new File("./src/main/resources/input.xlsx"));
			prop = new Properties();
			prop.load(propertiesFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	

	/*** To get the values from config.properties file ***/

	public static String getValue(String key) {
		return prop.getProperty(key);
	}

	/***************** returns WebElements *********/

	// Find a web element by its ID
	public static WebElement Id(String id) {
		return driver.findElement(By.id(getValue(id)));
	}

	// Find a web element by its name
	public static WebElement Name(String name) {
		return driver.findElement(By.name(getValue(name)));
	}

	// Find a web element by its class name
	public static WebElement ClassName(String className) {
		return driver.findElement(By.className(getValue(className)));
	}

	// Find a web element by its tag name
	public static WebElement TagName(String tagName) {
		return driver.findElement(By.tagName(getValue(tagName)));
	}

	// Find a web element by its link text
	public static WebElement LinkText(String linkText) {
		return driver.findElement(By.linkText(getValue(linkText)));
	}

	// Find a web element by its partial link text
	public static WebElement PartialLinkText(String partialLinkText) {
		return driver.findElement(By.partialLinkText(getValue(partialLinkText)));
	}

	// Find a web element by its CSS selector
	public static WebElement CssSelector(String cssSelector) {
		return driver.findElement(By.cssSelector(getValue(cssSelector)));
	}

	// Find a web element by its XPath
	public static WebElement XPath(String xpath) {
		return driver.findElement(By.xpath(getValue(xpath)));
	}

	public static List<WebElement> XPaths(String xpath) {
		return driver.findElements(By.xpath(getValue(xpath)));
	}

	/**************************** Explicit Wait Methods *******************/
	public static WebElement waitForElementClickable(WebElement element) {
		return new WebDriverWait(driver, Duration.ofSeconds(30))
				.until(ExpectedConditions.elementToBeClickable(element));
	}

	public static WebElement waitForElementVisible(WebElement element) {
		return new WebDriverWait(driver, Duration.ofSeconds(30)).until(ExpectedConditions.visibilityOf(element));
	}

	public static WebElement waitForElementPresent(WebElement element) {
		return new WebDriverWait(driver, Duration.ofSeconds(30))
				.until(ExpectedConditions.presenceOfElementLocated((By) element));
	}

	/************* To access keyboard button enter **************/

	public static void Enter() throws Exception {
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ENTER);
		robot.keyRelease(KeyEvent.VK_ENTER);
	}
	/************* To take ScreenShot **************/
	public static void takeScreenshot(String picName) {
	    try {
	        // create a rectangle encompassing the whole screen
	        Rectangle screenRect = new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
	        // create a robot to capture the screen
	        Robot robot = new Robot();
	        // capture the screen as an image
	        BufferedImage image = robot.createScreenCapture(screenRect);
	        // save the image to a file
	        ImageIO.write(image, "png", new File("./src/main/resources/screenshots/"+picName + ".png"));
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
}
