package UtilityClasses;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import BaseClasses.BrowserFactory;

public class DateUtils extends BrowserFactory {

	/*********** returns exact time stamp **************/

	public static String getTimestamp() {
		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MM yy HH:mm:ss.SSS");
		return now.format(formatter);
	}

	/*********** returns Tommarow date **************/
	public static String getTomorrowDate() {
		LocalDate tomorrow = LocalDate.now().plusDays(1);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d MMMM yyyy");
		return tomorrow.format(formatter);
	}

	/*********** returns 5 days from Tommarow date **************/
	public static String getFiveDaysFromTomorrowDate() {
		LocalDate tomorrow = LocalDate.now().plusDays(6);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d MMMM yyyy");
		return tomorrow.format(formatter);
	}

	/****** modify the Check-in date xpath ******************/
	public static WebElement CheckInDate() {
		String date = getTomorrowDate();
		String xpat = "//*[@id='BODY_BLOCK_JQUERY_REFLOW']//div[@aria-label='"+date+"']";
		WebElement checkin = driver.findElement(By.xpath(xpat));
	
		return checkin;

	}

	/****** modify the Check-out date xpath ******************/
	public static WebElement CheckOutDate() {
		String date = getFiveDaysFromTomorrowDate();
		String xpat = "//*[@id='BODY_BLOCK_JQUERY_REFLOW']//div[@aria-label='"+date+"']";
		WebElement checkout = driver.findElement(By.xpath(xpat));
		return checkout;

	}

	/******* Expected date used for assertins ***************/
	public static String ExpectedDate() {
		LocalDate tomorrow = LocalDate.now().plusDays(1);
		LocalDate fiveDaysFromTomorrow = tomorrow.plusDays(5);
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d MMM");

		String tomorrowFormatted = tomorrow.format(formatter);
		String fiveDaysFromTomorrowFormatted = fiveDaysFromTomorrow.format(formatter);

		return tomorrowFormatted + " → " + fiveDaysFromTomorrowFormatted;
	}
	
	
}
