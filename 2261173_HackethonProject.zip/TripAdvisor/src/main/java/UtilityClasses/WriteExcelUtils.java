package UtilityClasses;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.*;

public class WriteExcelUtils {
	/**
     * This method creates an Excel workbook with two sheets: "Holiday Homes" and "Cruises",
     * and writes the data from the given HashMaps to their respective sheets.
     * 
     * @param holidayHomes a HashMap<Integer, String[]> containing data for holiday homes
     * @param cruises a HashMap<Integer, String[]> containing data for cruises
     */
    public static void createWorkbook(Map<Integer, String[]> HolidayHomes,Map<Integer, String[]> Criuses) {
        XSSFWorkbook workbook = new XSSFWorkbook();
        XSSFSheet holidayHomesSheet = workbook.createSheet("Holiday Homes");
        XSSFSheet cruisesSheet = workbook.createSheet("Cruises");
        String[] s1Headings={"Name","Price/Night","Total Price"};
        String[] s2Headings={"Name","crew","Passengers","Launched Year","languages"};
        XSSFRow row =holidayHomesSheet.createRow(0);
        for(int i=0;i<3;i++) {
            Cell cell=row.createCell(i);
            cell.setCellValue(s1Headings[i]);
        }
        XSSFRow row1 =cruisesSheet.createRow(0);
        for(int i=0;i<5;i++) {
            Cell cell=row1.createCell(i);
            cell.setCellValue(s2Headings[i]);
        }
       
        writeHashMapToSheet(HolidayHomes, holidayHomesSheet);
        writeHashMapToSheet(Criuses, cruisesSheet);
        

        try {
            File outputFile = new File("./src/main/resources/Output.xlsx");
            FileOutputStream outputStream = new FileOutputStream(outputFile);
            workbook.write(outputStream);
            workbook.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void writeHashMapToSheet(Map<Integer, String[]> myHashMap, XSSFSheet sheetname) {
        for (Map.Entry<Integer, String[]> entry : myHashMap.entrySet()) {
            int rowNumber = entry.getKey();
            String[] values = entry.getValue();
            XSSFRow row = sheetname.createRow(rowNumber);
            for (int i = 0; i < values.length; i++) {
                XSSFCell cell = row.createCell(i);
                cell.setCellValue(values[i]);
            }
        }
    }

}
