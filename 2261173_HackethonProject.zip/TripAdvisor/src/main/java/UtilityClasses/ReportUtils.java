package UtilityClasses;
import java.io.IOException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
/**
This class provides methods to create and manage Extent Reports.
*/
public class ReportUtils {
  
	private static ExtentSparkReporter sparkReporter;
	private static ExtentReports extent;
	private static ExtentTest extentTest;
	/**
	 * Constructor to initialize Extent Reports and attach the report to the ExtentSparkReporter.
	 * @param BrowserName Name of the browser used for the test execution.
	 */
	public ReportUtils(String BrowserName)  {
		extent = new ExtentReports();
		sparkReporter = new ExtentSparkReporter("./src/main/resources/extent-report.html");
		extent.attachReporter(sparkReporter);

		sparkReporter.config().setOfflineMode(true);
		sparkReporter.config().setDocumentTitle("Automation Test Report");
		sparkReporter.config().setReportName("Extent Reports Demo");
		sparkReporter.config().setTheme(Theme.STANDARD);
		sparkReporter.config().setTimeStampFormat("MMM dd, yyyy HH:mm:ss");

		extent.setSystemInfo("OS", System.getProperty("os.name"));
		extent.setSystemInfo("Host Name", "Santhosh Kumar Neeli");
		extent.setSystemInfo("Environment", "Selenium with Java and TestNG");
		extent.setSystemInfo("Browser", BrowserName);
	}

	public static void startTest(String testName, String testDescription) {
		extentTest = extent.createTest(testName, testDescription);
	}

	public static void logInfo(String logMessage) {
		extentTest.log(Status.INFO, logMessage);
	}

	public static void logPass(String logMessage) {
		extentTest.log(Status.PASS, MarkupHelper.createLabel(logMessage, ExtentColor.GREEN));
	}

	public static void logFail(String logMessage) {
		extentTest.log(Status.FAIL, MarkupHelper.createLabel(logMessage, ExtentColor.RED));
	}

	public static void logSkip(String logMessage) {
		extentTest.log(Status.SKIP, MarkupHelper.createLabel(logMessage, ExtentColor.YELLOW));
	}

	public static void logException(Throwable throwable) {
		extentTest.log(Status.FAIL, throwable);
	}
	public static void addBugReport(String bugDescription) {
		extentTest.log(Status.FAIL, MarkupHelper.createLabel("Bug: " + bugDescription, ExtentColor.ORANGE));
	}
	
	public static void setSeverity(String severity) {
		extentTest.assignCategory(severity);
	}

	public static void addScreenshotToReport(String screenshotPath) throws IOException {
		extentTest.addScreenCaptureFromPath(screenshotPath);
	}

	public static void flushReport() {
		extent.flush();
	}
}