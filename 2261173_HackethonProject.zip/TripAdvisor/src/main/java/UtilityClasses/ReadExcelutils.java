package UtilityClasses;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ReadExcelutils {
	private static FileInputStream propertiesFile, ExcelInputFile, ExcelOutputFile;
	private static Properties prop;
	private static Workbook workbook;
	private static Sheet sheet;

	/*** To intialize the feilds before starting main class *********/
	public ReadExcelutils() {
		try {
			propertiesFile = new FileInputStream("./src/main/resources/config.properties");
			ExcelInputFile = new FileInputStream(new File("./src/main/resources/input.xlsx"));
			workbook = new XSSFWorkbook(ExcelInputFile);
			prop = new Properties();
			prop.load(propertiesFile);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/*********** returns data from excel **************/
	public static String getCellData(int rowNum, int colNum) {
		sheet = workbook.getSheet("Sheet1");
		Row row = sheet.getRow(rowNum - 1);
		Cell cell = row.getCell(colNum);
		return cell.getStringCellValue();
	}
	
}
