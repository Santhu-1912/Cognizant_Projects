package ErrorHandling;

import java.net.SocketException;
import java.util.NoSuchElementException;

import org.openqa.selenium.ElementNotInteractableException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import UtilityClasses.CommonUtils;
import UtilityClasses.LoggerUtils;
import UtilityClasses.ReportUtils;

public class InvalidSearch extends CommonUtils {
	public static void InvalidValue() throws Exception {
		LoggerUtils.info(CommonUtils.getValue("L1"));
		ReportUtils.startTest("Test case 1", CommonUtils.getValue("TC_1"));
		try {
			WebElement HolidayHomes = XPath("HolidayHome_Xpath");
			Thread.sleep(2000);
			waitForElementClickable(HolidayHomes);
			HolidayHomes.click();
			WebElement Search = XPath("Search_Where_To_Xpath");
			waitForElementVisible(Search);
			Search.sendKeys("mulakalc");
			Enter();
			Thread.sleep(4000);
			WebElement error = XPath("errormessege_Xpath");
			waitForElementVisible(error);

			Assert.assertEquals(error.getText(), getValue("errorSearchmessege"));
			driver.navigate().back();
			ReportUtils.logInfo(CommonUtils.getValue("TC_1_I"));
			ReportUtils.logPass(CommonUtils.getValue("TC_1_P"));
			LoggerUtils.info(CommonUtils.getValue("LO1"));
		} catch (SocketException | StaleElementReferenceException | ElementNotInteractableException | NoSuchElementException e) {
			LoggerUtils.error(CommonUtils.getValue("Log") ,e);
			ReportUtils.logFail(CommonUtils.getValue("TC_1_F") );

		}
		


	}
}
