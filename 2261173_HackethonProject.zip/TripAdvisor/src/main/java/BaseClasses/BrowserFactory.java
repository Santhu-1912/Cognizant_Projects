package BaseClasses;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Parameters;
import UtilityClasses.*;

public class BrowserFactory {
	protected static WebDriver driver;

	// Intilizing the browser from testNG.Xml
	@BeforeClass
	@Parameters("browserName")
	public static WebDriver createInstance(String browserName) {
		if (browserName.equalsIgnoreCase("chrome")) {
			System.out.println("chrome");
			driver = new ChromeDriver();
		} else if (browserName.equalsIgnoreCase("firefox")) {
			driver = new FirefoxDriver();
		} else if (browserName.equalsIgnoreCase("edge")) {
			driver = new EdgeDriver();
		}
		CommonUtils commonUtils = new CommonUtils();
		ReportUtils reportutils = new ReportUtils(browserName);
		ReadExcelutils excelutils = new ReadExcelutils();
		LoggerUtils loggerUtils = new LoggerUtils();
		return driver;
	}

	@AfterClass
	public void quit() {
		ReportUtils.flushReport();
		driver.close();
		driver.quit();
	}

}
